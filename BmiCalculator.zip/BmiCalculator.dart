import 'dart:io';

void main() {
  // INPUT BERAT DAN TINGGI
  print('\n=== BMI Calculator ===');
  // Menampilkan judul program
  print('Masukkan Berat badan muwh');
  double berat = double.parse(stdin.readLineSync()!);

  print('Jangan lupa tinggi badan nyh:');
  double tinggiCm = double.parse(stdin.readLineSync()!);

  // Konversi tinggi badan ke meter
  double tinggiMeter = tinggiCm / 100;

  // NGITUNG BMI
  double bmi = menghitungBMI(berat, tinggiMeter);

  // MENENTUKAN KATEGORI BMI
  String kategori = inputKategoriBMI(bmi);

  // OUTPUT BMI
  print('BMI-mu adalah: ${bmi.toStringAsFixed(2)}');
  print('Kategori BMI: $kategori');
}

double menghitungBMI(double berat, double tinggi) {
  return berat / (tinggi * tinggi);
}

String inputKategoriBMI(double bmi) {
  if (bmi < 18.5) {
    return 'Kamu Kurus banget sihh.... 😭';
  } else if (bmi >= 18.5 && bmi < 24.9) {
    return 'Fisiknya tolong di jaga yah 😘';
  } else if (bmi >= 25 && bmi < 29.9) {
    return 'Jangan berat-berat atuwh 😅';
  } else {
    return 'Bakpao 🥰';
  }
}


// ini BMI calculator. BMI body mass index atau yang di sebut sebagai indeks massa tubuh untuk menghitung berat badan ideal dalam skala BMI
//sepeti : underweight, normal, overweight, obese.

// 2. Meminta Pengguna Input
// Pertama, program akan menampilkan pesan untuk meminta kita memasukkan berat badan.
// Kemudian, program akan meminta kita memasukkan tinggi badan.
// Kode yang digunakan:

// dart
// Copy
// print('Masukkan Berad badan muwh:');
// double weight = double.parse(stdin.readLineSync()!);
// print('Jangan lupa tinggi badan nyh:');
// double height = double.parse(stdin.readLineSync()!);
// Jadi, di sini, program menunggu kita untuk memasukkan berat badan dan tinggi badan kita, kemudian disimpan dalam variabel weight dan height.

// 3. Menghitung BMI
// Setelah mendapatkan berat badan dan tinggi badan, program akan menghitung BMI (Body Mass Index) dengan rumus:
// BMI
// =
// Berat badan
// Tinggi badan
// ×
// Tinggi badan
// BMI=
// Tinggi badan×Tinggi badan
// Berat badan
// ​

// Kode untuk menghitung BMI:

// dart
// Copy
// double bmi = menghitungBMI(weight, height);
// Program memanggil fungsi menghitungBMI untuk menghitung nilai BMI berdasarkan berat badan dan tinggi badan yang kita masukkan tadi.

// 4. Menentukan Kategori BMI
// Setelah menghitung BMI, program akan menilai apakah BMI kita termasuk dalam kategori kurus, normal, gemuk, atau obesitas.
// Kode yang digunakan untuk menentukan kategori:

// dart
// Copy
// String kategori = inputKategoriBMI(bmi);
// Fungsi inputKategoriBMI akan mengecek nilai BMI dan menentukan kategori:

// BMI kurang dari 18.5: Kategori kurus.
// BMI antara 18.5 sampai 24.9: Kategori normal.
// BMI antara 25 sampai 29.9: Kategori gemuk.
// BMI lebih dari 30: Kategori obesitas.
// Program menggunakan if dan else untuk mengecek nilai BMI dan memberikan hasil kategori yang sesuai.

// 5. Menampilkan Hasil
// Setelah mendapatkan kategori BMI, program akan menampilkan hasil BMI dan kategori BMI kita ke layar.
// Kode untuk menampilkan hasil:

// dart
// Copy
// print('BMI MUWH ADLH: ${bmi.toStringAsFixed(2)}');
// print('KATEGORY BMI: $kategori');
// Jadi, di sini program akan menunjukkan BMI yang sudah dihitung dan kategori BMI berdasarkan hasil yang kita dapatkan.

// Kesimpulan
// Program ini meminta kita untuk memasukkan berat badan dan tinggi badan, lalu menghitung BMI menggunakan rumus.
// Setelah itu, program menentukan kategori BMI berdasarkan angka yang didapatkan.
// Akhirnya, program menampilkan hasil BMI dan kategorinya.
